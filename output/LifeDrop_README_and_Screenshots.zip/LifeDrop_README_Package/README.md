# 🩸 LifeDrop – Blood Bank Management System

A web-based Blood Bank Management System developed using **Java, Spring Boot, and MySQL**. LifeDrop helps organize donor information, search for donors, explore blood groups, and view blood inventory through a user-friendly web interface.

## 📌 Project Overview

LifeDrop is designed to simplify blood bank operations by organizing donor details and blood stock information in one place. The application includes donor registration, donor listings, blood group information, an inventory overview, and an administration dashboard.

## ✨ Features

- 📊 Dashboard with donor and inventory summaries
- 🩸 Blood stock and inventory overview
- 🧬 Information about the eight main blood groups
- 👥 Donor management and donor listing
- 📝 Donor registration
- 🔍 Donor search/navigation
- 🔐 Admin login interface
- 🌐 Web-based user interface
- 🗄️ MySQL database integration

## 🛠️ Technologies Used

- **Backend:** Java, Spring Boot, Spring MVC
- **Database:** MySQL
- **Data Access:** Spring Data JPA
- **Frontend:** HTML, CSS
- **Build Tool:** Maven

## 📸 Project Screenshots

The screenshots below show the main pages of the LifeDrop application.

### 🏠 1. Home Page

The homepage provides navigation to donor registration, donor search, blood groups, blood stock, dashboard, and project information.

![LifeDrop Home Page](screenshots/home.png)

### 📝 2. Donor Registration

The registration page collects donor details such as full name, age, blood group, phone number, and city.

![Donor Registration Page](screenshots/register-donor.png)

### 🔐 3. Admin Login

The admin login interface provides an entry point to the management dashboard.

![LifeDrop Admin Login](screenshots/admin-login.png)

### 📊 4. Admin Dashboard

The dashboard displays registered donor statistics, available blood units, tracked blood groups, donor locations, and inventory summaries.

![LifeDrop Dashboard](screenshots/dashboard.png)

### 🩸 5. Blood Inventory and Donor Summary

This dashboard section shows blood group stock levels and a summary of registered donors.

![Blood Inventory and Donor Summary](screenshots/dashboard-details.png)

### 🧬 6. Blood Groups

The blood groups page displays the eight main blood groups and provides navigation to donor search features.

![LifeDrop Blood Groups](screenshots/blood-groups.png)

### ❤️ 7. About LifeDrop

The About page explains the project's purpose and goal of organizing donor information and simplifying donor searches.

![About LifeDrop](screenshots/about.png)

## 💻 Prerequisites

Install the following before running the project:

1. Java JDK
2. MySQL Server
3. Maven, or the Maven Wrapper included with the project
4. A web browser
5. Git (optional)

Verify Java and Maven from PowerShell:

```powershell
java -version
mvn -version
```

## 📥 Installation and Setup

### Step 1: Get the Repository

Clone your repository, replacing the placeholder with your actual GitHub URL:

```bash
git clone YOUR_GITHUB_REPOSITORY_URL
```

Alternatively, download the repository ZIP from GitHub and extract it.

### Step 2: Open the Project Folder

In PowerShell, navigate to the folder containing `pom.xml`. Example:

```powershell
cd "C:\Users\Vasanth Kumar\Downloads\blood-bank\blood-bank"
```

Check the files:

```powershell
Get-ChildItem | Select-Object Name
```

### Step 3: Check the MySQL Database

Make sure the MySQL server is running and that your configured database exists. If your application is configured to use `blood_bank_db`, you can create it if it does not already exist:

```sql
CREATE DATABASE IF NOT EXISTS blood_bank_db;
```

Do not delete or recreate existing tables unnecessarily.

### Step 4: Configure the Database Connection

Open `src/main/resources/application.properties` and verify that the settings match your local MySQL installation. Example:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/blood_bank_db
spring.datasource.username=root
spring.datasource.password=YOUR_MYSQL_PASSWORD

spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
```

Replace `YOUR_MYSQL_PASSWORD` with your local password. Do not commit real passwords or other secrets to GitHub.

## ▶️ How to Run the Project

1. Start the MySQL server.
2. Open PowerShell in the project folder containing `pom.xml`.
3. Run the Maven Wrapper if `mvnw.cmd` is present:

```powershell
.\mvnw.cmd spring-boot:run
```

If the Maven Wrapper is not available but Maven is installed, run:

```powershell
mvn spring-boot:run
```

Wait for Spring Boot to finish starting and keep the terminal open while using the application.

Open the routes that are implemented in your project:

- Home: `http://localhost:8080/`
- Register Donor: `http://localhost:8080/register`
- Donors: `http://localhost:8080/donors`
- About: `http://localhost:8080/about`

The exact dashboard and page routes depend on your controller mappings. Stop the app with `Ctrl + C` in PowerShell.

## 📁 Project Structure

Your actual structure may vary, but the project may look similar to this:

```text
blood-bank/
├── pom.xml
├── mvnw
├── mvnw.cmd
├── src/
│   └── main/
│       ├── java/
│       │   └── blood_bank/
│       │       ├── controller/
│       │       ├── entity/
│       │       ├── repository/
│       │       └── ...
│       └── resources/
│           ├── application.properties
│           └── templates/
├── screenshots/
│   ├── home.png
│   ├── register-donor.png
│   ├── admin-login.png
│   ├── dashboard.png
│   ├── dashboard-details.png
│   ├── blood-groups.png
│   └── about.png
└── README.md
```

## 🗄️ Database Tables

The application may use these tables, depending on your entity mappings and database schema:

- `donors` – donor information
- `blood_stock` – blood inventory
- `blood_requests` – blood requests

## 🐛 Troubleshooting

- **MySQL connection error:** Check that MySQL is running and verify the URL, username, password, and port.
- **Maven command not recognized:** Use `mvnw.cmd` if included, or install Maven.
- **Port 8080 is busy:** Stop the other application using the port or configure a different port.
- **Page not found:** Verify the controller route and URL.
- **Application fails to start:** Review the last lines of the PowerShell error output.
- **Screenshots do not appear on GitHub:** Check that the `screenshots` folder and image filenames match the Markdown paths exactly.

## 🚀 Future Enhancements

- Blood availability search and filtering
- Blood request management
- Low-stock notifications
- Donor eligibility tracking
- Additional dashboard statistics
- Secure administrator authentication
- Cloud deployment

## 🎯 Project Objective

The objective of LifeDrop is to simplify blood bank information management through a web application while demonstrating practical skills in Java, Spring Boot, MySQL, and backend development.
